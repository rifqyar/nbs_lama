####################################################################

 Plugin: jQuery AJAX-ZOOM
 Copyright: Copyright (c) 2010 Jacobi Vadim
 License Agreement: http://www.ajax-zoom.com/index.php?cid=download
 Version: 3.3.0 Patch: 2012-09-08
 Date: 2011-08-03
 URL: http://www.ajax-zoom.com
 Documentation: http://www.ajax-zoom.com/index.php?cid=docs

####################################################################

Docs:
See http://www.ajax-zoom.com/index.php?cid=docs for general installation and configuration instructions.

360 in all ecommerce plugins:
See http://www.ajax-zoom.com/index.php?cid=docs#install_360_shops for understanding 360 deg. object spin & zoom in all ecommerce plugins.

Magento:
See http://www.ajax-zoom.com/index.php?cid=docs#install_magento for installation instructions for Magento store.

xt:Commerce, Veyton, xtcModified, Gambio:
See http://www.ajax-zoom.com/index.php?cid=docs#install_xtc for installation instructions for xt:Commerce, Veyton, xtcModified, Gambio.

Oxid eSales:
See http://www.ajax-zoom.com/index.php?cid=docs#install_oxid for installation instructions for Oxid eSales.

ASP.NET
Ajax-Zoom PHP component can run efficiently on ASP.NET 4.0 as a native fully managed 64-bit .NET application, as a part of ASP.NET web site. 
This is achieved thanks to Phalanger PHP compiler. See http://www.ajax-zoom.com/index.php?cid=docs#phalanger for more details.